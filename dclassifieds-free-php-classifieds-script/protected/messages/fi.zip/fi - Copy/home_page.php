﻿<?
return array(
	'pageTitle' 			=> 'Sivun otsikko',
	'pageDescription' 		=> 'Kuvaus sivusta',
	'pageKeywords' 			=> 'Avainsanat',
	'Latest Classifieds'	=> 'Uusimmat ilmoitukset',
	'Classifieds by Category' => 'Ilmoitukset luokittain'
);