﻿<?
return array(
	'Contact' => 'Ota yhteyttä'
);