﻿<?
return array(
	'Ups... No Classifieds Here' => 'Ei vielä ilmoituksia, jätä sinä ensimmäinen!',
	'Location' => 'Sijainti',
	'Category' => 'Kategoria',
	'Publish date' => 'Julkaistu',
	'Search' => 'Hae',
	'Categories' => 'Kategoriat',
	'Post an Ad' => 'Jätä ilmoitus',
	'Home' => 'Etusivu',
	'Locations' => 'Sijainnit',
	'Latest Tags' => 'Uusimmat avainsanat',
	'Subcategories' => 'Alakategoriat',
	'clear' => 'tyhjennä'
);