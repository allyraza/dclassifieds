﻿<?
return array(
	'Phone' => 'Puhelin',
	'Similar Classifieds' => 'Samankaltaisia ilmoituksia',
	'Contact' => 'Ota yhteyttä',
	'Ad Contact' => 'Ota yhteyttä',
	'Your E-Mail' => 'Sähköposti',
	'Your Message' => 'Viesti',
	'Enter the code above' => 'Syötä yllä oleva varmennuskoodi',
	'Your Message was send.' => 'Viestisi on lähetetty onnistuneesti!',
	'Send' => 'Lähetä',
	'Message' => 'Viesti',
	'You can view your classified ad here' => 'Voit katsoa ilmoituksesi tästä',
	'pic' => 'kuva',
	'of' => '/',
	'Control Ad Contact' => '[Ilmoitus] Sinulla on viesti',
	'Price' => 'Hinta',
	'price_sign' => 'EUR'
);