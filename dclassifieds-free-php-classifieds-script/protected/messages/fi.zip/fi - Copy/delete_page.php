﻿<?
return array(
	'pageTitle' => 'Ilmoituksen poistaminen',
	'pageDescription' => 'Ilmoituksen poistaminen',
	'pageKeywords' => 'Ilmoituksen poistaminen',
	'Delete code that you have recived by e-mail' => 'Syötä tähän ilmoituskohtainen poistokoodisi',
	'Delete' => 'Poista'
);