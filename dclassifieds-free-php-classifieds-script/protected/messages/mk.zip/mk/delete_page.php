<?
return array(
	'pageTitle' => 'Отстранете го огласот - ОГЛАСУВАЈ!',
	'pageDescription' => 'Отстранете го огласот',
	'pageKeywords' => 'Отстранете го огласот',
	'Delete code that you have recived by e-mail' => 'Кодот кој сте го добиле по Е-Пошта',
	'Delete' => 'Отстрани'
);
