<?
return array(
	'Contact' => 'Контакт'
);
