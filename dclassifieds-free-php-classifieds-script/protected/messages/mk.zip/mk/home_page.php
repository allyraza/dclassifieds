<?
return array(
	'pageTitle' 			=> 'ОГЛАСУВАЈ!',
	'pageDescription' 		=> 'Огласувајте слободно. Бесплатни интернет огласи.',
	'pageKeywords' 			=> 'огласувај, огласување, бесплатно, слободно',
	'Latest Classifieds'	=> 'Список на нови огласи',
	'Classifieds by Category' => 'Огласи по категорија'
);
