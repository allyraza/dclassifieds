<?
return array(
	'Error' => 'Грешка'
);