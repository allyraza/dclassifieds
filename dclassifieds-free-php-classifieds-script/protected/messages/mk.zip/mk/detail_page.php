﻿<?
return array(
	'Phone' => 'Телефон',
	'Similar Classifieds' => 'Слични огласи',
	'Contact' => 'Контакт',
	'Ad Contact' => 'Контакт за вашиот оглас',
	'Your E-Mail' => 'Вашата Е-Пошта',
	'Your Message' => 'Вашата порака',
	'Enter the code above' => 'Внесете го кодот',
	'Your Message was send.' => 'Вашата порака беше испратена.',
	'Send' => 'Испрати',
	'Message' => 'Порака',
	'You can view your classified ad here' => 'Можете да го видите вашиот оглас тука',
	'pic' => 'Слика',
	'of' => 'од',
	'Control Ad Contact' => '[Проверка] Контакт за вашиот оглас',
	'Price' => 'Цена',
	'price_sign' => '€'
);
