﻿<?
return array(
	'Ups... No Classifieds Here' => 'Опа ... Тука нема огласи',
	'Location' => 'Град',
	'Category' => 'Категорија',
	'Publish date' => 'Дата',
	'Search' => 'Барај',
	'Categories' => 'Категории',
	'Post an Ad' => 'Нов оглас',
	'Home' => 'Дома',
	'Locations' => 'Градови',
	'Latest Tags' => 'Последни клучни зборови',
	'Subcategories' => 'Подкатегории',
	'clear' => 'исчисти'
);
