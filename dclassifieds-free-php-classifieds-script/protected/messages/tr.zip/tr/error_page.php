<?
return array(
	'Error' => 'Hata'
);