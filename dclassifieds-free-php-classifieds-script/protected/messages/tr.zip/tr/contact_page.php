﻿<?
return array(
	'Contact' => 'İletişim'
);