﻿<?
return array(
	'Ups... No Classifieds Here' => 'Henüz ilan yok',
	'Location' => 'Şehir',
	'Category' => 'Kategori',
	'Publish date' => 'Yayın tarihi',
	'Search' => 'Ara',
	'Categories' => 'Kategoriler',
	'Post an Ad' => 'İlan gönder',
	'Home' => 'Anasayfa',
	'Locations' => 'Şehirler',
	'Latest Tags' => 'Son etiketler',
	'Subcategories' => 'Alt kategoriler',
	'clear' => 'Temizle'
);