﻿<?
return array(
	'pageTitle' 			=> 'Satılık traktör ilanları, ikinci el ve sıfır traktör',
	'pageDescription' 		=> 'Site tanımı',
	'pageKeywords' 			=> 'Anasayfa anahtar kelimeleri',
	'Latest Classifieds'	=> 'Son ilanlar',
	'Classifieds by Category' => 'İlan kategorileri'
);