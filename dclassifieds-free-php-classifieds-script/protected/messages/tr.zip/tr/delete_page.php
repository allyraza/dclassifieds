﻿<?
return array(
	'pageTitle' => 'İlan sil',
	'pageDescription' => 'İlan sil',
	'pageKeywords' => 'İlan sil',
	'Delete code that you have recived by e-mail' => 'Silme kodu eposta adresinizde',
	'Delete' => 'Sil'
);