﻿<?
return array(
	'Phone' => 'Telefon',
	'Similar Classifieds' => 'Benzer ilanlar',
	'Contact' => 'İletişim',
	'Ad Contact' => 'İletişim',
	'Your E-Mail' => 'E-mailiniz',
	'Your Message' => 'Mesajınız',
	'Enter the code above' => 'Yukarıdaki doğrulama kodunu giriniz',
	'Your Message was send.' => 'Mesajınız gönderildi.',
	'Send' => 'Gönder',
	'Message' => 'Mesaj',
	'You can view your classified ad here' => 'İlanınızı burada görebilirsiniz',
	'pic' => 'Resim',
	'of' => 'of',
	'Control Ad Contact' => '[Kontrol] İletişim',
	'Price' => 'Fiyat',
	'price_sign' => 'TL'
);